<div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="home.php">Administrator</a> 
</div>
<div style="color: white;padding: 15px 50px 5px 50px;float: right;font-size: 16px;"> 
    IP Address: <?php echo $_SERVER['REMOTE_ADDR']; ?> 
</div>
<style>
    #dataTables-example_filter label{float: right;}
    .pagination{float: right;}
</style>
