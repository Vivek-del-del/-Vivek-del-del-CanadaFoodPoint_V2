<?php
		if(!isset($_SESSION['utype']))
			{
			header("location:index.php");
			}
?>